function result = myGCVL0(A,W,D2,basis,gcv_option,kappas,gamma)

N = size(A,1);
nbasis = getnbasis(basis);
QW = W;% + gamma * D2;

if strcmp(gcv_option.cvType,'leaveout') == 1
    part  = cvpartition(N,'leaveout');
    K = N - 1;
else
    K = gcv_option.K;
    part = cvpartition(N,'Kfold',K);
end

result = zeros(length(kappas),K);

for pk = 1:part.NumTestSets
    trIdx = part.training(pk);
    teIdx = part.test(pk);
    
    Ap = A(trIdx,:); % coefficient matrix for the partition k

    kmin = min(kappas);
    [optY,optX,path] = myoptL0App(Ap,W,D2,nbasis,gamma,kmin);
    plen = length(path);
    
    for kpidx = 1:length(kappas)
        
        kappa = kappas(kpidx);
        diff = kappa - kmin;
        xik = optX(:,plen - diff);
        
        cQWc = xik' * QW * xik;
        At = A(teIdx,:);
        ETA = At - At * (QW * xik) * xik' / cQWc;
        resid = 0;
        for j = 1:size(ETA,1)
            veta = ETA(j,:);
            resid = resid  + veta * QW * veta';
        end
        result(kpidx,pk) = resid / size(ETA,1);
    end
end
    
    
end

