addpath('D:\Dropbox\fPCA\fdaM')

load('eeg.mat');

linewidth = 2.5;
fontsize = 15;


%%  plot the raw data


figure(1)
set(gcf,'Position',[100 100 400 350])
set(gcf, 'PaperPositionMode','auto')
plot(eegtime,eegmat);
xlabel('Time','fontsize',fontsize)
ylabel('Sensor Reading','fontsize',fontsize)
xlim([0,256]);
set(gca,'fontsize',12);
saveas(gcf,'Raw-data-eeg','epsc');
saveas(gcf,'Raw-data-eeg','fig');


%% plot estimated PCs

tobs = eegtime;
tbmat = eval_basis(eegtime,eegbasis);
pcaL0 = BB_L0 * tbmat';
pcaL2 = BB * tbmat';

% compute ylim and adjust the signs of FPCs

ylimit = zeros(1,2);
for np = 1:npca
    if np > 0
        pcaL0(np,:) = - pcaL0(np,:);
        BB_L0(np,:) = - BB_L0(np,:);
    end
    ylimit(1) = min(min(pcaL0(np,:)),ylimit(1));
    ylimit(2) = max(max(pcaL0(np,:)),ylimit(2));
end
for np = 1:npca
    pcas = BB(np,:);
    pcas = pcas(:);
    if np == 1
        pcas = - pcas;
        BB(np,:) = -BB(np,:);
    end
    pcas = pcas' * tbmat';
    ylimit(1) = min(min(pcas),ylimit(1));
    ylimit(2) = max(max(pcas),ylimit(2));
end
pcaL2 = BB * tbmat';
if ylimit(1) < 0
    ylimit(1) = ylimit(1) * 1.5;
else
    ylimit(1) = ylimit(1) * 0.9;
end
ylimit(2) = ylimit(2) * 1.1;


%% plot iFPCs v.s. FPCs
cum_opt = opt(1:npca);
cum_opt_L0 = opt_L0(1:npca);
temp = round(cum_opt.*1000./total_var);
temp_L0 = round(cum_opt_L0.*1000./total_var);

figure(3)
set(gcf,'Position',[50 100 1000 300])
set(gcf, 'PaperPositionMode','auto')
ylimitlower = [-0.1 -0.22 -0.25];
ylimitupper = [0.15 0.2 0.2];
for np = 1:npca
    
    subplot('position',[0.1+(np-1)*0.3,0.15,0.22,0.73])
    plot(tobs,pcaL0(np,:),'b-','linewidth',linewidth);
    hold on;
    plot(tobs,pcaL2(np,:),'r--','linewidth',linewidth);
    ylim([ylimitlower(np),ylimitupper(np)]);
    ylabel('Sensor Reading','fontsize',fontsize)
    xlabel('Time','fontsize',fontsize)
    xlim([0,256]);
    set(gca,'fontsize',fontsize);
    title(['FPC #' num2str(np)],'fontsize',fontsize);
    legendLoc = 'SouthEast';
    hLeg = legend(['iFPCA (',num2str(temp_L0(np)/10),'%)'],['FPCA (',num2str(temp(np)/10),'%)'],'Location',legendLoc);
    set(hLeg,'FontSize',10);

end
saveas(gcf,['eeg-estimated-pcs-g' num2str(gamma)],'epsc');
saveas(gcf,['eeg-estimated-pcs-g' num2str(gamma)],'fig');
hold off

% %% plot iFPCs v.s. FPCs [50-100]
% figure(30)
% set(gcf,'Position',[100 100 1000 380])
% set(gcf, 'PaperPositionMode','auto')
% ylimitlower = [-0.002 -0.05 -0.16];
% ylimitupper = [0.01 0.01 0.2];
% xlimitlower = [60 40 0];
% for np = 1:2
%     
%     subplot('position',[0.1+(np-1)*0.5,0.15,0.35,0.73])
%     plot(tobs,pcaL0(np,:),'b-','linewidth',linewidth);
%     hold on;
%     plot(tobs,pcaL2(np,:),'r--','linewidth',linewidth);
%     ylim([ylimitlower(np),ylimitupper(np)]);
%     ylabel('Squeeze','fontsize',fontsize)
%     xlabel('Time','fontsize',fontsize)
%     xlim([xlimitlower(np),100]);
%     set(gca,'fontsize',fontsize);
%     title(['FPC #' num2str(np) ' over [' num2str(xlimitlower(np)) ',100]'],'fontsize',fontsize);
%     LegLoc = 'NorthEast';
%     if np == 2
%         LegLoc = 'SouthEast';
%     end
%     legend('iFPCA','FPCA','Location',LegLoc);
% 
% end
% saveas(gcf,['eeg-estimated-pcs-g' num2str(gamma) '-zoomed'],'epsc');
% saveas(gcf,['eeg-estimated-pcs-g' num2str(gamma) '-zoomed'],'fig');
% hold off

% 
% %% plot an example basis function
% figure(14)
% set(gcf,'Position',[100 100 400 380])
% set(gcf, 'PaperPositionMode','auto')
%  
% s_knots = linspace(0,1,20)';
% s_nbasis   = length(s_knots) + 4 - 2;
% s_basis   = create_bspline_basis([0,1],s_nbasis,4,s_knots);
% 
% s_nobs = 101;
% s_tobs = linspace(0,1,s_nobs)';
% s_tbmat = eval_basis(s_tobs,s_basis);
% 
%     plot(s_tobs,s_tbmat(:,6),'linewidth',2)
%     set(gca,'fontsize',12)
%     xlabel('t','fontsize',fontsize);
%     ylabel('x(t)','fontsize',fontsize);
%     saveas(gcf,'example-basis-functions','epsc');
%     saveas(gcf,'example-basis-functions','fig');
% 
%     
% %% plot cumulative variance percentage
% 
% figure(4)
% set(gcf,'Position',[50 100 400 350])
% set(gcf, 'PaperPositionMode','auto')
% cum_opt = opt(1:npca);
% cum_opt_L0 = opt_L0(1:npca);
% 
% for i = 2:npca
%     cum_opt(i) = cum_opt(i) + cum_opt(i-1);
%     cum_opt_L0(i) = cum_opt_L0(i) + cum_opt_L0(i-1);
% end
% 
% cum_opt = cum_opt';
% cum_opt_L0 = cum_opt_L0';
% 
% plot(cum_opt_L0 * 100 / total_var,'b-','linewidth',linewidth);
% hold on;
% plot(cum_opt * 100 / total_var,'r--','linewidth',linewidth);
% hold off;
% set(gca,'XTick',1:1:npca);
% set(gca,'fontsize',fontsize);
% 
% ylim([0,105]);
% xlabel('Number of principal components','fontsize',fontsize);
% ylabel('Cumulative variance percentage (%)','fontsize',fontsize);
% legend('iFPCA','FPCA','Location','SouthEast');
% 
% saveas(gcf,'eeg-cumu-var-percentage','epsc');
% saveas(gcf,'eeg-cumu-var-percentage','fig');