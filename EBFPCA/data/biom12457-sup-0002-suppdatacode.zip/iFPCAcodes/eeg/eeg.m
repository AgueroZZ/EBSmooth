addpath('D:\Dropbox\fPCA\fdaM')
rand('seed',323);

load('eegmat.mat');

%preprocess;
%eegmat = XX;

%% set up basis
eegtime  = linspace(1,256,256)';
nbasis = 258;
eegbasis = create_bspline_basis([0,256], nbasis, 4);


%% fit the data without smoothing and remove the overall mean
eegmat_mean = eegmat;
tempfd = data2fd(eegmat_mean, eegtime, eegbasis);
tempfd = center(tempfd);
A = (getcoef(tempfd))';


%% Calculate inner product matrix W and D2

W = eval_penalty(eegbasis, int2Lfd(0));
D2 = eval_penalty(eegbasis, int2Lfd(2));


%% Set up argument for iFPCA

kappas = 1:nbasis;
npca = 3;
gamma = 1500; %800

BB = zeros(npca,nbasis);  % for vectors b when kappa=0
BB_L0 = zeros(npca,nbasis); % for vectors b when penalty applies
opt_L0 = zeros(1,npca); % optimal value when penalty applies
selected_kappas = zeros(1,npca);


%% compute all eigenvalues
M = size(A,1);
QN = W * (A' * A) * W;
QD = W+gamma*D2;
[U LA] = eigs(QN,QD);
LA = diag(LA);
total_var = sum(LA) / M;
[LAor LAidx] = sort(LA,'descend');

QW = W + gamma * D2;
A1 = A;
alpha = [1,0.1,0.1]; %1,0.1,0.1

%% Begin iFPCA Algorithm
for np = 1:npca
    np
    % the deflation step except for the first PC
    if np > 1
        cc = BB_L0(np-1,:);
        cc = cc(:);
        A1 = A1 - A1 * W * cc * (cc') / (cc' * W * cc);
    end

    % GCV to find the kappa
    cvoption = struct('cvType','Kfold','K',10);
    result = myGCVL0App(A1,W,D2,eegbasis,cvoption,kappas,gamma);
    res = mean(result,2);
    [Y, kappa2] = min(res);
    kappa2 = find(res < Y+alpha(np)*std(result(kappa2,:)),1,'first');
    kappa = kappa2;
    selected_kappas(np) = kappa;

    % use the selected kappa to get iFPCs
    [optY,optX] = myoptL0App(A1,W,D2,nbasis,gamma,kappa);
    BB_L0(np,:) = optX;
    opt_L0(np) = optY;

end

%% compute the Silverman's regularized FPCs
for np = 1:npca
    optX = U(:,LAidx(np));
    optX = optX ./ sqrt(optX' * QW * optX);
    BB(np,:) = optX';
end
opt = LA(LAidx(1:npca)) / M;

%%
save('eeg.mat');
