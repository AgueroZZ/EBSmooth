function [optY,optX,path] = myoptL0(X,W,D2,nbasis,gamma,kappa)

% U:  the matrix U of [U Z V] = svd(D)
% D:  R * A * A' * R
% R:  the root of W
% Rinv: inv(R)
% M:  the number of curves

    A = W * (X' * X) * W;
    B = W + gamma * D2;
    
    B = (B + B') ./ 2;
    A = (A + A') ./ 2;
    
    R = B;
    
    M = size(X,1);

    kk = nbasis;
    Bi = (eye(size(B,1))/B);
    BiA = Bi * A;
    [U LA] = eigs(A,B,1);
    v = U;
    v = v / sqrt(sum(v.*v));
    orglVarIdx = 1:nbasis;
    computePath = false;
    if nargout == 3 && kappa < nbasis
        computePath = true;
    end
    
    
    if computePath == true
        path = zeros(1,nbasis-kappa+1);
        optY = zeros(1,length(path));
        optX = zeros(nbasis,length(path));
    end
    
    while kk > kappa
        
        if computePath == true
            b = zeros(nbasis,1);
            b(orglVarIdx) = v;
            b = b / sqrt(b' * R * b);

            optVal = LA;% b' * QN * b;

            optX(:,nbasis-kk+1) = b;
            optY(nbasis-kk+1) = optVal/M;
        end
        
        diff = zeros(1,kk);
        for i = 1:kk
            y = Bi(i,i);
            g = Bi(:,i);
            p2 = BiA(:,i);
            c = BiA(i,i);
            nt1 = v(i) * (sum(v .* g)-v(i)*y) / y;
            nt2 = v(i) * (sum(v .* p2)-v(i)*c);
            diff(i) = (nt1+nt2) / (1-v(i)^2);
        end
        [Y i] = min(diff);
        if computePath == true
            path(nbasis-kk+1) = orglVarIdx(i);
        end
        varIdx = logical(ones(1,kk));
        varIdx(i) = false;
        BiA = BiA(varIdx,varIdx) - Bi(varIdx,i)*BiA(i,varIdx)/Bi(i,i);
        Bi = Bi(varIdx,varIdx) - Bi(varIdx,i) * Bi(i,varIdx) / Bi(i,i);
        A = A(varIdx,varIdx);
        B = B(varIdx,varIdx);
        orglVarIdx = orglVarIdx(varIdx);
        kk = kk - 1;
        if size(A,1) == 1
            U = [1];
            LA = A(1,1) / B(1,1);
        else
            [U LA] = eigs(A,B,1);
        end
        v = U;
        v = v / sqrt(sum(v.*v));
    end

    b = zeros(nbasis,1);
    b(orglVarIdx) = v;
    b = b / sqrt(b' * R * b);
    
    optVal = LA;% b' * QN * b;

    if computePath == false
        optX = b;
        optY = optVal/M;
    else
        optX(:,nbasis-kk+1) = b;
        optY(nbasis-kk+1) = optVal/M;
    end
end